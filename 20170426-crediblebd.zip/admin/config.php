<?php
// HTTP
define('HTTP_SERVER', 'http://crediblebd.net/admin/');
define('HTTP_CATALOG', 'http://crediblebd.net/');

// HTTPS
define('HTTPS_SERVER', 'http://crediblebd.net/admin/');
define('HTTPS_CATALOG', 'http://crediblebd.net/');

// DIR
define('DIR_APPLICATION', '/home/credible/public_html/admin/');
define('DIR_SYSTEM', '/home/credible/public_html/system/');
define('DIR_IMAGE', '/home/credible/public_html/image/');
define('DIR_LANGUAGE', '/home/credible/public_html/admin/language/');
define('DIR_TEMPLATE', '/home/credible/public_html/admin/view/template/');
define('DIR_CONFIG', '/home/credible/public_html/system/config/');
define('DIR_CACHE', '/home/credible/public_html/system/storage/cache/');
define('DIR_DOWNLOAD', '/home/credible/public_html/system/storage/download/');
define('DIR_LOGS', '/home/credible/public_html/system/storage/logs/');
define('DIR_MODIFICATION', '/home/credible/public_html/system/storage/modification/');
define('DIR_UPLOAD', '/home/credible/public_html/system/storage/upload/');
define('DIR_CATALOG', '/home/credible/public_html/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'credible_rana');
define('DB_PASSWORD', 'O#5s!op');
define('DB_DATABASE', 'credible_opencart');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
